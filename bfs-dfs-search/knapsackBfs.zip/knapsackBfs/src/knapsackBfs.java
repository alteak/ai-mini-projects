import java.util.*;

class Item {
    int id;
    int benefit;
    int weight;

    public Item(int id, int benefit, int weight) {
        this.id = id;
        this.benefit = benefit;
        this.weight = weight;
    }
}

class Node {
    int benefit;
    int weight;
    int level;
    boolean[] taken;

    public Node(int benefit, int weight, int level, boolean[] taken) {
        this.benefit = benefit;
        this.weight = weight;
        this.level = level;
        this.taken = taken;
    }
}

public class knapsackBfs {
    public static void knapsackBFS(int bagCapacity, Item[] items) {
        int dimensions = items.length;
        int benefitAccumulated = 0;
        int weightAccumulated = 0;
        // "tree"/queue with the nodes we're going to analyze/expand
        Queue<Node> queue = new LinkedList<>();
        queue.add(new Node(0, 0, -1, new boolean[dimensions])); //knapsack is empty
        //the array to store the best solution
        List<Integer> takenItems = new ArrayList<>();
        while (!queue.isEmpty()) {
            Node node = queue.poll(); // extracting the first node on the queue
            if (node.level == dimensions -1) { // checks if this is leaf node
                if (node.benefit > benefitAccumulated) { // if yes -> updated with values of the current node (no -> generate child nodes and add them to the end of the queue)
                    benefitAccumulated = node.benefit;
                    weightAccumulated = node.weight;
                    takenItems.clear();
                    for (int i = 0; i < dimensions; i++) {
                        if (node.taken[i]) { // check if item is taken
                            takenItems.add(items[i].id);
                        }
                    }
                }
                continue; // when lead node is processed
            }
            // generating the next level nodes
            int nextLevel=node.level+1;
            boolean[] taken = Arrays.copyOf(node.taken, dimensions);
            taken[nextLevel] = true;
            // included item
            int totalWeight= node.weight+items[nextLevel].weight;
            if (totalWeight<=bagCapacity) {
                queue.add(new Node(node.benefit + items[nextLevel].benefit,
                        totalWeight,nextLevel, taken));
            }
            // exluded item
            queue.add(new Node(node.benefit, node.weight,nextLevel, node.taken));
        }
        System.out.println("Results using Breadth-First Search");
        System.out.println("Items taken: " + takenItems);
        System.out.println("Total weight: " + weightAccumulated);
        System.out.println("Benefit: " + benefitAccumulated);
    }

    public static void main(String[] args) {

        int bagCapacity = 420;

        Item[] items = new Item[] {
                new Item(1, 20, 15),
                new Item(2, 40, 32),
                new Item(3, 50, 60),
                new Item(4, 36, 80),
                new Item(5, 26, 43),
                new Item(6, 64, 120),
                new Item(7, 54, 77),
                new Item(8, 18, 6),
                new Item(9, 46, 93),
                new Item(10, 28, 35),
                new Item(11, 25, 37)
        };

        knapsackBFS(bagCapacity, items);

    }
}
