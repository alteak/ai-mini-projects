import java.util.*;

class Item {
    int id;
    int benefit;
    int weight;
    public Item(int id, int benefit, int weight) {
        this.id = id;
        this.benefit = benefit;
        this.weight = weight;
    }
}
class Node {
    int benefit;
    int weight;
    int level;
    boolean[] taken;
    public Node(int benefit, int weight, int level, boolean[] taken) {
        this.benefit = benefit;
        this.weight = weight;
        this.level = level;
        this.taken = taken;
    }
}
public class knapsackDfs {
    public static void knapsackDFS(int bagCapacity, Item[] items) {
        int dimensions = items.length;
        int benefitAccumulated = 0;
        int weightAccumulated = 0;
        Stack<Node> stack = new Stack<>();
        stack.push(new Node(0, 0, -1, new boolean[dimensions]));
        List<Integer> takenItems = new ArrayList<>();
        while (!stack.isEmpty()) {
            Node node = stack.pop();
            if (node.level == dimensions - 1) {
                // reached the end of the tree
                if (node.benefit > benefitAccumulated) {
                    benefitAccumulated = node.benefit;
                    weightAccumulated = node.weight;
                    takenItems.clear();
                    for (int i = 0; i < dimensions; i++) {
                        if (node.taken[i]) {
                            takenItems.add(items[i].id);
                        }
                    }
                }
                continue;
            }
            // generate next level nodes
            int nextLevel = node.level + 1;
            boolean[] taken = Arrays.copyOf(node.taken, dimensions);
            taken[nextLevel] = true;
            // consider the node where the next item is taken
            int newWeight = node.weight + items[nextLevel].weight;
            if (newWeight <= bagCapacity) { // new node created and pushed onto the stack
                stack.push(new Node(node.benefit + items[nextLevel].benefit,
                        newWeight, nextLevel, taken));
            }

            // consider the exluded item node
            stack.push(new Node(node.benefit, node.weight, nextLevel, node.taken));
        }
        System.out.println("Results using Depth-First Search:");
        System.out.println("Items included: " + takenItems);
        System.out.println("Total weight: " + weightAccumulated + "/420");
        System.out.println("Benefit: " + benefitAccumulated);

    }

    public static void main(String[] args) {
        int bagCapacity = 420;

        Item[] items = new Item[]{
                new Item(1, 20, 15),
                new Item(2, 40, 32),
                new Item(3, 50, 60),
                new Item(4, 36, 80),
                new Item(5, 26, 43),
                new Item(6, 64, 120),
                new Item(7, 54, 77),
                new Item(8, 18, 6),
                new Item(9, 46, 93),
                new Item(10, 28, 35),
                new Item(11, 25, 37)
        };

        knapsackDFS(bagCapacity, items);
    }
}
